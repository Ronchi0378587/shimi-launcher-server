﻿using System;
using System.IO;
using System.Net.Http;
using System.Threading.Tasks;
using System.Windows;

namespace ShimiLauncherWPF
{
    public partial class MainWindow : Window
    {
        string zipUrl = "https://raw.githubusercontent.com/Ronchi0378587/shimi-launcher-server/main/shimiiiiii.zip";

        public MainWindow()
        {
            InitializeComponent();
        }

        private async void Install_Click(object sender, RoutedEventArgs e)
        {
            await Install();
        }

        private async Task Install()
        {
            try
            {
                string mcPath = Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                    ".minecraft",
                    "resourcepacks"
                );

                Directory.CreateDirectory(mcPath);

                // 🔥 שם הקובץ שלך
                string packPath = Path.Combine(mcPath, "shimiiiiii.zip");

                // 🔥 אם קיים → למחוק רק אותו
                if (File.Exists(packPath))
                {
                    File.Delete(packPath);
                }

                StatusText.Text = "DOWNLOADING...";
                Progress.Value = 0;

                using (HttpClient client = new HttpClient())
                using (var response = await client.GetAsync(zipUrl, HttpCompletionOption.ResponseHeadersRead))
                using (var stream = await response.Content.ReadAsStreamAsync())
                using (var file = new FileStream(packPath, FileMode.Create))
                {
                    var buffer = new byte[8192];
                    long totalRead = 0;
                    var total = response.Content.Headers.ContentLength ?? -1L;

                    int read;

                    while ((read = await stream.ReadAsync(buffer, 0, buffer.Length)) > 0)
                    {
                        await file.WriteAsync(buffer, 0, read);
                        totalRead += read;

                        if (total > 0)
                        {
                            double percent = (double)totalRead / total * 100;

                            Dispatcher.Invoke(() =>
                            {
                                Progress.Value = percent;
                                StatusText.Text = $"DOWNLOADING... {percent:0}%";
                            });
                        }
                    }
                }

                StatusText.Text = "INSTALLED ✔";
                Progress.Value = 100;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}